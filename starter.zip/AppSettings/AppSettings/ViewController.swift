//
//  ViewController.swift
//  AppSettings
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tryAppSettings()
        print("\n\n")
        tryPlayerSettings()
    }

    
    
    func tryAppSettings() {
        
    }
    
    
    func tryPlayerSettings() {
        
    }
    
}

